<b>MiniSumo Project</b>
<br>
This repository contains all files, designs and codes used for built MiniSumo of Tamandutech.
<br>
<br>
<b>Contacts</b>
<br>
Pedro Gabriel Gengo Lourenço  - pedro.gabriel.lourenco@hotmail.com
<br>
Henrique Zanferrari Hadermeck - henriquezanferrari@gmail.com 
